Author: Jinglin Li (jxl163530)

The text file that I choose is the book “A Tale of Two Cities" by Charles Dickens
the direct link https://www.gutenberg.org/files/98/98-0.txt

This file includes WordCount.jar, to run the program, run:
java -jar WordCount.jar > jxl163530Part2.txt

This file also includes WordCount.java, the source code of WordCount. 

