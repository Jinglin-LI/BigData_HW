Author: Jinglin Li (jxl163530)

The text file that I choose is the book “A Tale of Two Cities" by Charles Dickens
the direct link https://www.gutenberg.org/files/98/98-0.txt


To run the Script, run:
bash assignment0.sh
