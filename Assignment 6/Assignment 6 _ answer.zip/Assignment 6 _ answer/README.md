Big Data _ Assignment 6


PartI: GraphX:

Databricks link:
https://databricks-prod-cloudfront.cloud.databricks.com/public/4027ec902e239c93eaaa8714f173bcfc/2827628494694427/2321483240095863/3643796919102713/latest.html

DataSet:
https://snap.stanford.edu/data/ca-HepTh.html



PartII: Spark Streaming

Databricks link:
https://databricks-prod-cloudfront.cloud.databricks.com/public/4027ec902e239c93eaaa8714f173bcfc/2986581375807848/653208726438054/5078786695261930/latest.html

Library:
Please find them in the library file.